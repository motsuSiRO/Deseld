#define NOMINMAX
#include <assert.h>
#include "RigidBody.h"
#include "DebugDrawManager.h"

inline void rotate_vector_by_quaternion(D3DXVECTOR3 *out, const D3DXQUATERNION &q, const D3DXVECTOR3 &v)
{
#if 1
	D3DXVECTOR3 p;
	p.x = 2.0f * (q.x * v.x + q.y * v.y + q.z * v.z) * q.x + (q.w * q.w - (q.x * q.x + q.y * q.y + q.z * q.z)) * v.x + 2.0f * q.w * (q.y * v.z - q.z * v.y);
	p.y = 2.0f * (q.x * v.x + q.y * v.y + q.z * v.z) * q.y + (q.w * q.w - (q.x * q.x + q.y * q.y + q.z * q.z)) * v.y + 2.0f * q.w * (q.z * v.x - q.x * v.z);
	p.z = 2.0f * (q.x * v.x + q.y * v.y + q.z * v.z) * q.z + (q.w * q.w - (q.x * q.x + q.y * q.y + q.z * q.z)) * v.z + 2.0f * q.w * (q.x * v.y - q.y * v.x);
	*out = p;
#else
	D3DXQUATERNION conjugate, p( v.x, v.y, v.z, 0 );
	D3DXQuaternionConjugate( &conjugate, &q );
	p = conjugate * p * q;
	out->x = p.x;
	out->y = p.y;
	out->z = p.z;
#endif
}

INT generate_contact_sphere_sphere(Sphere *s0, Sphere *s1, std::vector<Contact> *contacts, FLOAT restitution)
{
	//2�̋��̂̏Փ˔�����s��
	//�Փ˂��Ă���ꍇ��Contact�I�u�W�F�N�g�𐶐�����
	//Contact�̑S�Ẵ����o�ϐ��ɒl���Z�b�g���A�R���e�i(contacts)�ɒǉ�����
	assert(s0 != s1);

	D3DXVECTOR3 p0 = s0->position;
	D3DXVECTOR3 p1 = s1->position;

	D3DXVECTOR3 n = p0 - p1;
	FLOAT l = D3DXVec3Length(&n);
	D3DXVec3Normalize(&n, &n);
	if (l < s0->r + s1->r)
	{
		Contact contact;
		contact.normal = n;
		contact.penetration = s0->r + s1->r - l;
		//contact.point = p1 + 0.5f * l * n;
		contact.point = p1 + (s1->r - (0.5f * contact.penetration)) * n;
		contact.body[0] = s0;
		contact.body[1] = s1;
		contact.restitution = restitution;
		contacts->push_back(contact);
		return 1;
	}
	return 0;
}
INT generate_contact_sphere_plane(Sphere *sphere, Plane *plane, std::vector<Contact> *contacts, FLOAT restitution, BOOL half_space)
{
	//���̂ƕ��ʂ̏Փ˔�����s��
	//�Փ˂��Ă���ꍇ��Contact�I�u�W�F�N�g�𐶐�����
	//Contact�̑S�Ẵ����o�ϐ��ɒl���Z�b�g���A�R���e�i(contacts)�ɒǉ�����
	//��half_space���^�̏ꍇ�͕ЖʁA�U�̏ꍇ�͗��ʂ̏Փ˔�����s��
	D3DXMATRIX matrix, inverse_matrix;
	D3DXMatrixRotationQuaternion(&matrix, &plane->orientation);
	matrix._41 = plane->position.x;
	matrix._42 = plane->position.y;
	matrix._43 = plane->position.z;
	D3DXVECTOR3 n(matrix._21, matrix._22, matrix._23);
	D3DXMatrixInverse(&inverse_matrix, 0, &matrix);

	D3DXVECTOR3 p;
	D3DXVec3TransformCoord(&p, &sphere->position, &inverse_matrix);

	//Half-space
	if (half_space && p.y < 0) return 0;

	if (fabsf(p.y) < sphere->r)
	{
		Contact contact;
		contact.normal = p.y > 0 ? n : -n;
		contact.point = sphere->position + p.y * -n;
		contact.penetration = sphere->r - fabsf(p.y);
		contact.body[0] = sphere;
		contact.body[1] = plane;
		contact.restitution = restitution;
		contacts->push_back(contact);
		return 1;
	}
	return 0;
}
INT generate_contact_sphere_box(Sphere *sphere, Box *box, std::vector<Contact> *contacts, FLOAT restitution)
{
	//�@���̂ƒ����̂̏Փ˔�����s��
	//�Փ˂��Ă���ꍇ��Contact�I�u�W�F�N�g�𐶐�����
	//Contact�̑S�Ẵ����o�ϐ��ɒl���Z�b�g���A�R���e�i(contacts)�ɒǉ�����
	D3DXMATRIX boxM_space, R, T;
	D3DXMatrixTranslation(&T, box->position.x, box->position.y, box->position.z);
	D3DXMatrixRotationQuaternion(&R, &box->orientation);
	D3DXVECTOR3 dimension = box->get_dimension();
	boxM_space = R * T;
	D3DXMATRIX Inverse_boxM_space;
	D3DXMatrixInverse(&Inverse_boxM_space, NULL, &boxM_space);
	
	D3DXVECTOR3 sp;
	D3DXVec3TransformCoord(&sp, &sphere->position, &Inverse_boxM_space);

	D3DXVECTOR3 closest_pt = sp;
	if (closest_pt.x > box->half_size.x)closest_pt.x = box->half_size.x;
	if (closest_pt.x < -box->half_size.x)closest_pt.x = -box->half_size.x;

	if (closest_pt.y > box->half_size.y)closest_pt.y = box->half_size.y;
	if (closest_pt.y < -box->half_size.y)closest_pt.y = -box->half_size.y;

	if (closest_pt.z > box->half_size.z)closest_pt.z = box->half_size.z;
	if (closest_pt.z < -box->half_size.z)closest_pt.z = -box->half_size.z;

	FLOAT dist = D3DXVec3Length(&(closest_pt - sp));

	if (dist < sphere->r && dist > FLT_EPSILON)
	{
		D3DXVec3TransformCoord(&closest_pt, &closest_pt, &boxM_space);

		Contact contact;
		D3DXVec3Normalize(&contact.normal, &(sphere->position - closest_pt));
		contact.point = closest_pt;
		contact.penetration = sphere->r - dist;
		contact.body[0] = sphere;
		contact.body[1] = box;
		contact.restitution = restitution;
		contacts->push_back(contact);
	}

	return 0;
}
INT generate_contact_box_plane(Box *box, Plane *plane, std::vector<Contact> *contacts, FLOAT restitution)
{
	//�A�����̂ƕ��ʂ̏Փ˔�����s��
	//�Փ˂��Ă���ꍇ��Contact�I�u�W�F�N�g�𐶐�����
	//Contact�̑S�Ẵ����o�ϐ��ɒl���Z�b�g���A�R���e�i(contacts)�ɒǉ�����
	INT contacts_used = 0;	// ��������Contact�I�u�W�F�N�g�̐��i���t���[���ɏՓ˂����|�C���g�̐��j
	
	D3DXVECTOR3 vertices[8] =
	{
		D3DXVECTOR3(-box->half_size.x, -box->half_size.y, -box->half_size.z),
		D3DXVECTOR3(-box->half_size.x, -box->half_size.y, +box->half_size.z),
		D3DXVECTOR3(-box->half_size.x, +box->half_size.y, -box->half_size.z),
		D3DXVECTOR3(-box->half_size.x, +box->half_size.y, +box->half_size.z),
		D3DXVECTOR3(+box->half_size.x, -box->half_size.y, -box->half_size.z),
		D3DXVECTOR3(+box->half_size.x, -box->half_size.y, +box->half_size.z),
		D3DXVECTOR3(+box->half_size.x, +box->half_size.y, -box->half_size.z),
		D3DXVECTOR3(+box->half_size.x, +box->half_size.y, +box->half_size.z)
	};

	D3DXVECTOR3 n;
	rotate_vector_by_quaternion(&n, plane->orientation, D3DXVECTOR3(0, 1, 0));
	FLOAT d = D3DXVec3Dot(&n, &plane->position);

	for (int i = 0; i < 8; i++)
	{
		rotate_vector_by_quaternion(&vertices[i], box->orientation, vertices[i]);
		vertices[i] += box->position;


		FLOAT distance = D3DXVec3Dot(&vertices[i], &n);

		if (distance < d)
		{
			Contact contact;
			contact.normal = n;
			contact.point = vertices[i];
			contact.penetration = d - distance;
			contact.body[0] = box;
			contact.body[1] = plane;
			contact.restitution = restitution;

			// �����Փ˂��N���邽�߁A�ő�߂荞�ݗʂ����|�C���g�ł̂݁A�߂荞�ݗʂ̏������s��
			float maxPenetration = 0.0f;
			for (int j = 0; j < contacts->size(); j++)
			{
				if ((*contacts)[j].penetration > maxPenetration)
				{
					maxPenetration = (*contacts)[j].penetration;
				}
			}
			if (maxPenetration < contact.penetration)
			{
				contact.penetFlg = true;

				// ����܂ł̂߂荞�݃t���O��false��
				for (int j = 0; j < contacts->size(); j++)
				{
					(*contacts)[j].penetFlg = false;
				}
			}
			else
			{
				contact.penetFlg = false;
			}

			contacts->push_back(contact);

			contacts_used++;
		}
	}
	
	return contacts_used;
}


void Contact::resolve()
{
	assert(penetration > 0);

	//David Baraff[1997] An Introduction to Physically Based Modeling:Rigid Body Simulation II - Nonpenetration Constraints pp.40-47
	//Baraff[1997]�̎�(8-1)(8-2)(8-3)����ՓˑO�̑��Α��x(vrel)�����߂�
	FLOAT vrel = 0;

	//(8-1)
	D3DXVECTOR3 pdota;
	D3DXVec3Cross(&pdota, &body[0]->old_angular_velocity, &(point - body[0]->position));
	pdota += body[0]->old_linear_velocity ;

	//(8-2)
	D3DXVECTOR3 pdotb;
	D3DXVec3Cross(&pdotb, &body[1]->old_angular_velocity, &(point - body[1]->position));
	pdotb += body[1]->old_linear_velocity ;

	//(8-3)
	vrel = D3DXVec3Dot(&normal, &(pdota - pdotb));

	//Baraff[1997]�̎�(8-18)�̕��q(numerator)�����߂�
	FLOAT numerator = 0;
	numerator = -(1 + restitution) * vrel;

	//Baraff[1997]�̎�(8-18)�̕���(denominator)�����߂�
	FLOAT denominator = 0;
	FLOAT term1 = body[0]->inverse_mass();
	FLOAT term2 = body[1]->inverse_mass();
	D3DXVECTOR3 ra = point - body[0]->position;
	D3DXVECTOR3 rb = point - body[1]->position;
	D3DXVECTOR3 ta, tb;
	D3DXVec3Cross(&ta, &ra, &normal);
	D3DXVec3Cross(&tb, &rb, &normal);
	D3DXVec3TransformCoord(&ta, &ta, &body[0]->inverse_inertia_tensor());
	D3DXVec3TransformCoord(&tb, &tb, &body[1]->inverse_inertia_tensor());
	D3DXVec3Cross(&ta, &ta, &ra);
	D3DXVec3Cross(&tb, &tb, &rb);
	FLOAT term3 = D3DXVec3Dot(&normal, &ta);
	FLOAT term4 = D3DXVec3Dot(&normal, &tb);
	denominator = term1 + term2 + term3 + term4;

	//Baraff[1997]�̎�(8-18)�̌���(j)�����߂�
	FLOAT j = 0;
	j = numerator / denominator;

	//Baraff[1997]�̎�(8-12)���e���̂̕��i���x(linear_velocity)�Ɗp���x(angular_velocity)���X�V����
	D3DXVECTOR3 impulse = j * normal;

	body[0]->linear_velocity += impulse * body[0]->inverse_mass();
	D3DXVec3Cross(&ta, &ra, &impulse);
	D3DXVec3TransformCoord(&ta, &ta, &body[0]->inverse_inertia_tensor());
	body[0]->angular_velocity += ta;

	body[1]->linear_velocity -= impulse * body[1]->inverse_mass();
	D3DXVec3Cross(&tb, &rb, &impulse);
	D3DXVec3TransformCoord(&tb, &tb, &body[1]->inverse_inertia_tensor());
	body[1]->angular_velocity -= tb;

	//�߂荞�ݗʂ̉���
	if (penetFlg)
	{
		body[0]->position += penetration * (body[1]->inertial_mass / (body[0]->inertial_mass + body[1]->inertial_mass)) * normal;
		body[1]->position -= penetration * (body[0]->inertial_mass / (body[0]->inertial_mass + body[1]->inertial_mass)) * normal;
	}
}

