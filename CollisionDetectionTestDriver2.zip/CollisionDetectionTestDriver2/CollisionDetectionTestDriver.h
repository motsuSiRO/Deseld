#include "Particle.h"
#include "RigidBody.h"

void get_normalized_cursor_position(FLOAT *x, FLOAT *y)
{
	POINT p; GetCursorPos(&p);
	HWND hwnd = GetActiveWindow(); ScreenToClient(hwnd, &p);
	RECT rc; GetClientRect(hwnd, &rc);
	FLOAT hw = (rc.right - rc.left) * 0.5f;
	FLOAT hh = (rc.bottom - rc.top) * 0.5f;
	*x = FLOAT(p.x - hw) / hw;
	*y = -FLOAT(p.y - hh) / hh;
}
D3DXVECTOR3 screen_to_world(
	const D3DXMATRIX &P	/*Projection matrix*/,
	const D3DXMATRIX &V	/*View matrix*/,
	FLOAT x, FLOAT y, FLOAT z	/*Normalized screen coordinates*/
	)
{
	D3DXMATRIX _V;
	D3DXMATRIX _P;
	D3DXMatrixInverse(&_V, 0, &V);
	D3DXMatrixInverse(&_P, 0, &P);

	D3DXVECTOR3 p(x, y, z);
	D3DXVec3TransformCoord(&p, &p, &(_P * _V));
	return p;
}

class CollisionDetectionTestDriver : public Scene
{
	LPD3DXMESH box, sphere;
	Sphere *sphere_body;
	Box *box_body;
	Plane *plane_body;
	std::vector<D3DXVECTOR3> pts;


public:
	CollisionDetectionTestDriver(LPDIRECT3DDEVICE9 d3dd) : sphere(0), box(0)
	{
		D3DXCreateBox(d3dd, 1, 1, 1, &box, 0);
		D3DXCreateSphere(d3dd, 1, 12, 12, &sphere, 0);

		sphere_body = new Sphere(0.5f, 1);
		sphere_body->position = D3DXVECTOR3(-2, 0.5f, 0);
		sphere_body->linear_velocity = D3DXVECTOR3(+1, 0, 0);

		box_body = new Box(D3DXVECTOR3(0.4f, 0.4f, 0.4f), 0.1f);
		box_body->position = D3DXVECTOR3(+2, 0, 0);
		box_body->linear_velocity = D3DXVECTOR3(-1, 0, 0);

		plane_body = new Plane(D3DXVECTOR3(0, 1, 0), -2);
	}
	~CollisionDetectionTestDriver()
	{
		if (box) box->Release();
		if (sphere) sphere->Release();
		if (sphere_body) delete sphere_body;
		if (box_body) delete box_body;
		if (plane_body) delete plane_body;
	}
	void Update(FLOAT duration)
	{

		if (!GetAsyncKeyState('A'))
		{
			for (std::vector<D3DXVECTOR3>::iterator i = pts.begin(); i != pts.end(); i++)
			{
				_DDM::I().AddCross(*i, 0.2f, _DDM::WHITE, 0);
			}

			Scene::Update(duration);
			return;
		}

		//�ڐG(Contact)�p�R���e�i
		std::vector<Contact> contacts;
		//�Փ˔���(�ڐG�̐���)
		generate_contact_sphere_box(sphere_body, box_body, &contacts, 0.999f);
		generate_contact_sphere_plane(sphere_body, plane_body, &contacts, 0.999f);
		int maxCount = generate_contact_box_plane(box_body, plane_body, &contacts, 0.7f);
		
		for (std::vector<Contact>::iterator i = contacts.begin(); i != contacts.end(); i++)
		{
			i->resolve();
			pts.push_back(i->point);
			_DDM::I().AddCross(i->point, 0.2f, _DDM::WHITE, 0);
		}

		sphere_body->integrate(duration);
		box_body->integrate(duration);
		plane_body->integrate(duration);
		Scene::Update(duration);
	}

	D3DXMATRIX V;
	D3DXMATRIX P;
	void Render(LPDIRECT3DDEVICE9 d3dd)
	{
		{
			D3DXMatrixLookAtLH(&V,
			&(comera_position * comera_distance * 0.3f),
			&D3DXVECTOR3(0.0f, 0.0f, 0.0f),
			&D3DXVECTOR3(0.0f, 1.0f, 0.0f)
			);
			d3dd->SetTransform(D3DTS_VIEW, &V);

			RECT rect;
			if (GetClientRect(GetActiveWindow(), &rect))
			{
				D3DXMatrixPerspectiveFovLH(&P, 60 * 0.01745f, (FLOAT)rect.right / rect.bottom, 0.001f, 1000.0f);
				d3dd->SetTransform(D3DTS_PROJECTION, &P);
			}

			D3DLIGHT9 l = { D3DLIGHT_DIRECTIONAL, 0 };
			l.Ambient = l.Diffuse = D3DXCOLOR(0.8f, 0.8f, 0.8f, 1.0f);
			l.Direction = D3DXVECTOR3(0, 0, 1);
			d3dd->SetLight(0, &l);
			d3dd->LightEnable(0, TRUE);
		}

		D3DMATERIAL9 m = { 0 };

		D3DXMATRIX M, R, S, T;
		D3DXMatrixIdentity(&M);


		m.Ambient = m.Diffuse = D3DXCOLOR(0.6f, 0.1f, 0.1f, 1.0f);
		d3dd->SetMaterial(&m);

		//d3dd->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
		d3dd->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
		RenderRigidBody(d3dd, sphere_body);
		RenderRigidBody(d3dd, box_body);
		RenderRigidBody(d3dd, plane_body);

		D3DXVECTOR3 O(0, 0, 0), X(100, 0, 0), Y(0, 100, 0), Z(0, 0, 100);
		_DDM::DrawLine(d3dd, O, X, _DDM::RED);
		_DDM::DrawLine(d3dd, O, Y, _DDM::GREEN);
		_DDM::DrawLine(d3dd, O, Z, _DDM::BLUE);

		//d3dd->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
		d3dd->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
		_DDM::I().DrawQ(d3dd);
	}
	void RenderRigidBody(LPDIRECT3DDEVICE9 d3dd, RigidBody *body)
	{
		D3DXMATRIX M, R, S, T;

		//���̃I�u�W�F�N�g(RigidBody)�̐��@���擾����
		D3DXVECTOR3 dimension = body->get_dimension();

		//RTTI�ō��̃I�u�W�F�N�g(RigidBody)�̐����^�𔻕ʂ���
		//���̃I�u�W�F�N�g�̕`��
		if (dynamic_cast<Sphere *>(body))
		{
			//sphere���b�V���͔��a��1�ō쐬���Ă���
			D3DXMatrixScaling(&S, dimension.x, dimension.y, dimension.z);
			D3DXMatrixRotationQuaternion(&R, &body->orientation);
			M = S * R;
			M._41 = body->position.x;
			M._42 = body->position.y;
			M._43 = body->position.z;
			d3dd->SetTransform(D3DTS_WORLD, &M);
			sphere->DrawSubset(0);
		}
		//�{�b�N�X�I�u�W�F�N�g�̕`��
		else if (dynamic_cast<Box *>(body))
		{
			//box���b�V���͂P�ӂ̒�����1�ō쐬���Ă���
			D3DXMatrixScaling(&S, dimension.x * 2, dimension.y * 2, dimension.z * 2);
			D3DXMatrixRotationQuaternion(&R, &body->orientation);
			M = S * R;
			M._41 = body->position.x;
			M._42 = body->position.y;
			M._43 = body->position.z;
			d3dd->SetTransform(D3DTS_WORLD, &M);
			box->DrawSubset(0);
		}
		//���ʃI�u�W�F�N�g�̕`��
		else if (dynamic_cast<Plane *>(body))
		{
			//box���b�V���͂P�ӂ̒�����1�ō쐬���Ă���
			D3DXMatrixScaling(&S, dimension.x * 5, dimension.y * 0, dimension.z * 5);
			D3DXMatrixRotationQuaternion(&R, &body->orientation);
			M = S * R;
			M._41 = body->position.x;
			M._42 = body->position.y;
			M._43 = body->position.z;
			d3dd->SetTransform(D3DTS_WORLD, &M);
			box->DrawSubset(0);
		}
	}
};

